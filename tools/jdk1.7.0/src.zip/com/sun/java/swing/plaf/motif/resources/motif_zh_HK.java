package com.sun.java.swing.plaf.motif.resources;

import java.util.ListResourceBundle;

public final class motif_zh_HK extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.acceptAllFileFilter.textAndMnemonic", "*" },
            { "FileChooser.cancelButton.textAndMnemonic", "\u53D6\u6D88" },
            { "FileChooser.cancelButtonToolTip.textAndMnemonic", "\u4E2D\u6B62\u6A94\u6848\u9078\u64C7\u5668\u5C0D\u8A71\u65B9\u584A\u3002" },
            { "FileChooser.enterFileNameLabel.textAndMnemonic", "\u8F38\u5165\u6A94\u6848\u540D\u7A31:" },
            { "FileChooser.enterFolderNameLabel.textAndMnemonic", "\u8F38\u5165\u8CC7\u6599\u593E\u540D\u7A31:" },
            { "FileChooser.filesLabel.textAndMnemonic", "\u6A94\u6848" },
            { "FileChooser.filterLabel.textAndMnemonic", "\u7BE9\u9078" },
            { "FileChooser.foldersLabel.textAndMnemonic", "\u8CC7\u6599\u593E" },
            { "FileChooser.helpButton.textAndMnemonic", "\u8AAA\u660E" },
            { "FileChooser.helpButtonToolTip.textAndMnemonic", "\u300C\u6A94\u6848\u9078\u64C7\u5668\u300D\u8AAA\u660E\u3002" },
            { "FileChooser.openButton.textAndMnemonic", "\u78BA\u5B9A" },
            { "FileChooser.openButtonToolTip.textAndMnemonic", "\u958B\u555F\u9078\u53D6\u7684\u6A94\u6848\u3002" },
            { "FileChooser.openDialogTitle.textAndMnemonic", "\u958B\u555F" },
            { "FileChooser.pathLabel.textAndMnemonic", "\u8F38\u5165\u8DEF\u5F91\u6216\u8CC7\u6599\u593E\u540D\u7A31:" },
            { "FileChooser.saveButton.textAndMnemonic", "\u5132\u5B58" },
            { "FileChooser.saveButtonToolTip.textAndMnemonic", "\u5132\u5B58\u9078\u53D6\u7684\u6A94\u6848\u3002" },
            { "FileChooser.saveDialogTitle.textAndMnemonic", "\u5132\u5B58" },
            { "FileChooser.updateButton.textAndMnemonic", "\u66F4\u65B0" },
            { "FileChooser.updateButtonToolTip.textAndMnemonic", "\u66F4\u65B0\u76EE\u9304\u6E05\u55AE\u3002" },
        };
    }
}
