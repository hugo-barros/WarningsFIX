package com.sun.java.swing.plaf.gtk.resources;

import java.util.ListResourceBundle;

public final class gtk_ja extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.acceptAllFileFilter.textAndMnemonic", "\u3059\u3079\u3066\u306E\u30D5\u30A1\u30A4\u30EB" },
            { "FileChooser.cancelButton.textAndMnemonic", "\u53D6\u6D88(&C)" },
            { "FileChooser.cancelButtonToolTip.textAndMnemonic", "\u30D5\u30A1\u30A4\u30EB\u30FB\u30C1\u30E5\u30FC\u30B6\u30FB\u30C0\u30A4\u30A2\u30ED\u30B0\u3092\u7D42\u4E86\u3057\u307E\u3059\u3002" },
            { "FileChooser.deleteFileButton.textAndMnemonic", "\u30D5\u30A1\u30A4\u30EB\u306E\u524A\u9664(&L)" },
            { "FileChooser.filesLabel.textAndMnemonic", "\u30D5\u30A1\u30A4\u30EB(&F)" },
            { "FileChooser.filterLabel.textAndMnemonic", "\u30D5\u30A3\u30EB\u30BF:" },
            { "FileChooser.foldersLabel.textAndMnemonic", "\u30D5\u30A9\u30EB\u30C0(&D)" },
            { "FileChooser.newFolderButton.textAndMnemonic", "\u65B0\u898F\u30D5\u30A9\u30EB\u30C0(&N)" },
            { "FileChooser.newFolderDialog.textAndMnemonic", "\u30D5\u30A9\u30EB\u30C0\u540D:" },
            { "FileChooser.newFolderNoDirectoryError.textAndMnemonic", "\u30C7\u30A3\u30EC\u30AF\u30C8\u30EA\"{0}\"\u306E\u4F5C\u6210\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F: \u3053\u306E\u30D5\u30A1\u30A4\u30EB\u307E\u305F\u306F\u30C7\u30A3\u30EC\u30AF\u30C8\u30EA\u306F\u5B58\u5728\u3057\u307E\u305B\u3093" },
            { "FileChooser.newFolderNoDirectoryErrorTitle.textAndMnemonic", "\u30A8\u30E9\u30FC" },
            { "FileChooser.openButton.textAndMnemonic", "OK(&O)" },
            { "FileChooser.openButtonToolTip.textAndMnemonic", "\u9078\u629E\u3057\u305F\u30D5\u30A1\u30A4\u30EB\u3092\u958B\u304D\u307E\u3059\u3002" },
            { "FileChooser.openDialogTitle.textAndMnemonic", "\u958B\u304F" },
            { "FileChooser.pathLabel.textAndMnemonic", "\u9078\u629E(&S):" },
            { "FileChooser.renameFileButton.textAndMnemonic", "\u30D5\u30A1\u30A4\u30EB\u306E\u540D\u524D\u5909\u66F4(&R)" },
            { "FileChooser.renameFileDialog.textAndMnemonic", "\u30D5\u30A1\u30A4\u30EB\"{0}\"\u3092\u6B21\u306E\u540D\u524D\u306B\u5909\u66F4:" },
            { "FileChooser.renameFileError.textAndMnemonic", "\u30D5\u30A1\u30A4\u30EB\"{0}\"\u306E\"{1}\"\u3078\u306E\u5909\u66F4\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F" },
            { "FileChooser.renameFileError.titleAndMnemonic", "\u30A8\u30E9\u30FC" },
            { "FileChooser.saveButton.textAndMnemonic", "OK(&O)" },
            { "FileChooser.saveButtonToolTip.textAndMnemonic", "\u9078\u629E\u3057\u305F\u30D5\u30A1\u30A4\u30EB\u3092\u4FDD\u5B58\u3057\u307E\u3059\u3002" },
            { "FileChooser.saveDialogTitle.textAndMnemonic", "\u4FDD\u5B58" },
            { "GTKColorChooserPanel.blue.textAndMnemonic", "\u9752(&B):" },
            { "GTKColorChooserPanel.color.textAndMnemonic", "\u8272\u540D(&N):" },
            { "GTKColorChooserPanel.green.textAndMnemonic", "\u7DD1(&G):" },
            { "GTKColorChooserPanel.hue.textAndMnemonic", "\u8272\u76F8(&H):" },
            { "GTKColorChooserPanel.red.textAndMnemonic", "\u8D64(&E):" },
            { "GTKColorChooserPanel.saturation.textAndMnemonic", "\u5F69\u5EA6(&S):" },
            { "GTKColorChooserPanel.textAndMnemonic", "GTK\u30AB\u30E9\u30FC\u30FB\u30C1\u30E5\u30FC\u30B6(&G)" },
            { "GTKColorChooserPanel.value.textAndMnemonic", "\u5024(&V):" },
        };
    }
}
