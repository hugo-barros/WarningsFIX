package com.sun.java.swing.plaf.gtk.resources;

import java.util.ListResourceBundle;

public final class gtk_ko extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.acceptAllFileFilter.textAndMnemonic", "\uBAA8\uB4E0 \uD30C\uC77C" },
            { "FileChooser.cancelButton.textAndMnemonic", "\uCDE8\uC18C(&C)" },
            { "FileChooser.cancelButtonToolTip.textAndMnemonic", "\uD30C\uC77C \uC120\uD0DD\uAE30 \uB300\uD654\uC0C1\uC790\uB97C \uC911\uB2E8\uD569\uB2C8\uB2E4." },
            { "FileChooser.deleteFileButton.textAndMnemonic", "\uD30C\uC77C \uC0AD\uC81C(&L)" },
            { "FileChooser.filesLabel.textAndMnemonic", "\uD30C\uC77C(&F)" },
            { "FileChooser.filterLabel.textAndMnemonic", "\uD544\uD130:" },
            { "FileChooser.foldersLabel.textAndMnemonic", "\uD3F4\uB354(&D)" },
            { "FileChooser.newFolderButton.textAndMnemonic", "\uC0C8 \uD3F4\uB354(&N)" },
            { "FileChooser.newFolderDialog.textAndMnemonic", "\uD3F4\uB354 \uC774\uB984:" },
            { "FileChooser.newFolderNoDirectoryError.textAndMnemonic", "\"{0}\" \uB514\uB809\uD1A0\uB9AC\uB97C \uC0DD\uC131\uD558\uB294 \uC911 \uC624\uB958 \uBC1C\uC0DD: \uD574\uB2F9 \uD30C\uC77C \uB610\uB294 \uB514\uB809\uD1A0\uB9AC\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4." },
            { "FileChooser.newFolderNoDirectoryErrorTitle.textAndMnemonic", "\uC624\uB958" },
            { "FileChooser.openButton.textAndMnemonic", "\uD655\uC778(&O)" },
            { "FileChooser.openButtonToolTip.textAndMnemonic", "\uC120\uD0DD\uB41C \uD30C\uC77C\uC744 \uC5FD\uB2C8\uB2E4." },
            { "FileChooser.openDialogTitle.textAndMnemonic", "\uC5F4\uAE30" },
            { "FileChooser.pathLabel.textAndMnemonic", "\uC120\uD0DD \uC0AC\uD56D(&S):" },
            { "FileChooser.renameFileButton.textAndMnemonic", "\uD30C\uC77C \uC774\uB984 \uBC14\uAFB8\uAE30(&R)" },
            { "FileChooser.renameFileDialog.textAndMnemonic", "\"{0}\" \uD30C\uC77C\uC758 \uC774\uB984 \uBC14\uAFB8\uAE30" },
            { "FileChooser.renameFileError.textAndMnemonic", "\"{0}\" \uD30C\uC77C\uC758 \uC774\uB984\uC744 \"{1}\"(\uC73C)\uB85C \uBC14\uAFB8\uB294 \uC911 \uC624\uB958\uAC00 \uBC1C\uC0DD\uD588\uC2B5\uB2C8\uB2E4." },
            { "FileChooser.renameFileError.titleAndMnemonic", "\uC624\uB958" },
            { "FileChooser.saveButton.textAndMnemonic", "\uD655\uC778(&O)" },
            { "FileChooser.saveButtonToolTip.textAndMnemonic", "\uC120\uD0DD\uB41C \uD30C\uC77C\uC744 \uC800\uC7A5\uD569\uB2C8\uB2E4." },
            { "FileChooser.saveDialogTitle.textAndMnemonic", "\uC800\uC7A5" },
            { "GTKColorChooserPanel.blue.textAndMnemonic", "\uD30C\uB780\uC0C9(&B):" },
            { "GTKColorChooserPanel.color.textAndMnemonic", "\uC0C9\uC0C1 \uC774\uB984(&N):" },
            { "GTKColorChooserPanel.green.textAndMnemonic", "\uB179\uC0C9(&G):" },
            { "GTKColorChooserPanel.hue.textAndMnemonic", "\uC0C9\uC870(&H):" },
            { "GTKColorChooserPanel.red.textAndMnemonic", "\uBE68\uAC04\uC0C9(&E):" },
            { "GTKColorChooserPanel.saturation.textAndMnemonic", "\uCC44\uB3C4(&S):" },
            { "GTKColorChooserPanel.textAndMnemonic", "GTK \uC0C9\uC0C1 \uC120\uD0DD\uAE30(&G)" },
            { "GTKColorChooserPanel.value.textAndMnemonic", "\uAC12(&V):" },
        };
    }
}
