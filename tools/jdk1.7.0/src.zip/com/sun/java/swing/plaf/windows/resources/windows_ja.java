package com.sun.java.swing.plaf.windows.resources;

import java.util.ListResourceBundle;

public final class windows_ja extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabel.textAndMnemonic", "\u8A73\u7D30" },
            { "FileChooser.detailsViewButtonAccessibleName", "\u8A73\u7D30" },
            { "FileChooser.detailsViewButtonToolTip.textAndMnemonic", "\u8A73\u7D30" },
            { "FileChooser.fileAttrHeader.textAndMnemonic", "\u5C5E\u6027" },
            { "FileChooser.fileDateHeader.textAndMnemonic", "\u4FEE\u6B63\u65E5" },
            { "FileChooser.fileNameHeader.textAndMnemonic", "\u540D\u524D" },
            { "FileChooser.fileNameLabel.textAndMnemonic", "\u30D5\u30A1\u30A4\u30EB\u540D:" },
            { "FileChooser.fileSizeHeader.textAndMnemonic", "\u30B5\u30A4\u30BA" },
            { "FileChooser.fileTypeHeader.textAndMnemonic", "\u30BF\u30A4\u30D7" },
            { "FileChooser.filesOfTypeLabel.textAndMnemonic", "\u30D5\u30A1\u30A4\u30EB\u306E\u30BF\u30A4\u30D7:" },
            { "FileChooser.folderNameLabel.textAndMnemonic", "\u30D5\u30A9\u30EB\u30C0\u540D:" },
            { "FileChooser.homeFolderAccessibleName", "\u30DB\u30FC\u30E0" },
            { "FileChooser.homeFolderToolTip.textAndMnemonic", "\u30DB\u30FC\u30E0" },
            { "FileChooser.listViewActionLabel.textAndMnemonic", "\u30EA\u30B9\u30C8" },
            { "FileChooser.listViewButtonAccessibleName", "\u30EA\u30B9\u30C8" },
            { "FileChooser.listViewButtonToolTip.textAndMnemonic", "\u30EA\u30B9\u30C8" },
            { "FileChooser.lookInLabel.textAndMnemonic", "\u53C2\u7167:" },
            { "FileChooser.newFolderAccessibleName", "\u65B0\u898F\u30D5\u30A9\u30EB\u30C0" },
            { "FileChooser.newFolderActionLabel.textAndMnemonic", "\u65B0\u898F\u30D5\u30A9\u30EB\u30C0" },
            { "FileChooser.newFolderToolTip.textAndMnemonic", "\u65B0\u898F\u30D5\u30A9\u30EB\u30C0\u306E\u4F5C\u6210" },
            { "FileChooser.refreshActionLabel.textAndMnemonic", "\u30EA\u30D5\u30EC\u30C3\u30B7\u30E5" },
            { "FileChooser.saveInLabel.textAndMnemonic", "\u4FDD\u5B58:" },
            { "FileChooser.upFolderAccessibleName", "\u4E0A\u3078" },
            { "FileChooser.upFolderToolTip.textAndMnemonic", "1\u30EC\u30D9\u30EB\u4E0A\u3078" },
            { "FileChooser.viewMenuButtonAccessibleName", "\u8868\u793A\u30E1\u30CB\u30E5\u30FC" },
            { "FileChooser.viewMenuButtonToolTipText", "\u8868\u793A\u30E1\u30CB\u30E5\u30FC" },
            { "FileChooser.viewMenuLabel.textAndMnemonic", "\u8868\u793A" },
        };
    }
}
